package id.hikmah.stiki.tandur_1.v2.util

enum class State {
    LOADING,
    ERROR,
    COMPLETE,
}