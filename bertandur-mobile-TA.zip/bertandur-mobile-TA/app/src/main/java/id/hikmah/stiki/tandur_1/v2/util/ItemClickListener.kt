package id.hikmah.stiki.tandur_1.v2.util


interface ItemClickListener<T> {
    fun onClickItem(item : T)
}