package id.hikmah.stiki.tandur_1.v2

import android.app.Application


class TandurApp: Application() {

}