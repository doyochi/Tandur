package id.hikmah.stiki.tandur_1.helper

enum class Status {
    SUCCESS,
    ERROR,
    LOADING
}